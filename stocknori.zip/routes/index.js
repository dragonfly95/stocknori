var express = require('express');
var router = express.Router();

var pgDBConn = require('./pgDBConn');
const pool = pgDBConn.getClient();


function contentlist(cb) {
  let query = 'SELECT content_name, content_id FROM web.content_ids\n' +
      'WHERE login_id = $1 \n' +
      'ORDER BY content_name ASC';
  pool.query(query, ['kkk']).then(results => {
    cb( results.rows);
  }).catch(error => new Error())
}


/* dashboard */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'DashBoard' })
});

router.get('/login', (req, res) => {
  res.render('login', { title: 'Login' })
})


router.post('/login', (req, res) => {
  console.log(req)
  let userId = req.body.userId;
  let userPass = req.body.userPass;

  if (userId === 'kkk' && userPass === '1234') {
    req.session.user = {
      id: userId
    };
    res.redirect('/');
  } else {
    res.redirect('/login');
  }
})

router.get('/chart_daily', (req, res) => {
  let date = new Date();
  contentlist(function (rows) {
    res.render('chart_daily', {
      title: '1일데이타',
      start: getFormatDate(date),
      end: getFormatDate(date),
      contentlist: rows
    })
  });

})


router.get('/chart_monthly', (req, res) => {
  let date = new Date();
  let prev_date = new Date();
  prev_date.setMonth(prev_date.getMonth()-1);

  contentlist(function (rows) {
    res.render('chart_monthly', {
      title: '1달 데이타',
      start: getFormatDate(prev_date),
      end: getFormatDate(date),
      contentlist: rows
    })
  });

});


router.get('/chart_effective', (req, res) => {
  let date = new Date();
  contentlist(function (rows) {
    res.render('chart_effective', {
      title: '효율',
      start: getFormatDate(date),
      end: getFormatDate(date),
      contentlist: rows
    })
  });
});


router.get('/chart_isp', (req, res) => {
  let date = new Date();
  contentlist(function (rows) {
    res.render('chart_isp', {
      title: 'ISP별',
      start: getFormatDate(date),
      end: getFormatDate(date),
      contentlist: rows
    })
  });

});

/**
 *  yyyyMMdd 포맷으로 반환
 */
function getFormatDate(date){
  var year = date.getFullYear();              //yyyy
  var month = (1 + date.getMonth());          //M
  month = month >= 10 ? month : '0' + month;  //month 두자리로 저장
  var day = date.getDate();                   //d
  day = day >= 10 ? day : '0' + day;          //day 두자리로 저장
  return  year + '-' + month + '-' + day;       //'-' 추가하여 yyyy-mm-dd 형태 생성 가능
}
module.exports = router;
