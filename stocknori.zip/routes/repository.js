var express = require('express');
var router = express.Router();

var pgDBConn = require('./pgDBConn');
const pool = pgDBConn.getClient();

/* GET users listing. */
router.get('/', function(req, res) {
  res.status(404).json({"msessage": "잘못된 접근입니다"});
});


/*
SELECT content_name, content_id FROM web.content_ids
WHERE login_id = 'kkk'
ORDER BY content_name ASC
 */
router.get('/contentlist', ((req, res) => {

  let query = 'SELECT content_name, content_id FROM web.content_ids\n' +
      'WHERE login_id = $1 \n' +
      'ORDER BY content_name ASC';
  pool.query(query, ['kkk']).then(results => {
    res.status(200).json(results.rows);
  }).catch(error => new Error())
}));

/*
SELECT update_time,cdn,p2p FROM web.dn_day
WHERE update_time >2021-04-22 00:00'
  AND update_time <2021-04-23 00:05'
  AND content_id = 1
ORDER BY update_time ASC
 */
router.get('/daily', (req, res) => {

  let start = req.query.start;
  let end  = req.query.end;
  let content_id = req.query.content_id;

  let query = 'SELECT update_time,cdn,p2p FROM web.dn_day\n' +
      'WHERE update_time > $1 \n' +
      'AND update_time < $2 \n' +
      'AND content_id = $3\n' +
      'ORDER BY update_time ASC';
  pool.query(query, [`${start}  00:00`, `${end} 00:05`, content_id]).then(results => {
    res.status(200).json(results.rows);
  }).catch(error => new Error())
})


/*
SELECT update_date, cdn, p2p FROM web.dn_month
WHERE update_date >'2021-04-22'
AND update_date <'2021-04-23'
AND content_id = 0
ORDER BY update_date ASC
 */
router.get('/monthly', (req, res) => {

  let start = req.query.start;
  let end  = req.query.end;
  let content_id = req.query.content_id;

  let query = 'SELECT update_date, cdn, p2p FROM web.dn_month\n' +
      'WHERE update_date >= $1 \n' +
      'AND update_date < $2 \n' +
      'AND content_id = $3\n' +
      'ORDER BY update_date ASC';
  pool.query(query, [start, end, content_id]).then(results => {
    res.status(200).json(results.rows);
  }).catch(error => new Error())
})

/*
SELECT update_time, ((cdn*100)/(cdn+p2p))::integer FROM web.dn_day
WHERE update_time >'2021-04-22 00:00'
AND update_time <'2021-04-23 00:05'
AND content_id = 1
ORDER BY update_time ASC
 */
router.get('/effective', (req, res) => {

  let start = req.query.start;
  let end  = req.query.end;
  let content_id = req.query.content_id;

  let query = 'SELECT update_time, ((cdn*100)/(cdn+p2p))::integer FROM web.dn_day\n' +
      'WHERE update_time > $1 \n' +
      'AND update_time < $2 \n' +
      'AND content_id = $3 \n' +
      'ORDER BY update_time ASC';
  pool.query(query, [`${start}  00:00`, `${end} 00:05`, content_id]).then(results => {
    res.status(200).json(results.rows);
  }).catch(error => new Error())
})


/*
SELECT update_time, kt, sk, lg, etc  FROM web.isp_day
WHERE update_time >'2021-04-22 00:00'
AND update_time <'2021-04-23 00:05'
AND owner_isp = '0'
AND content_id = 0
ORDER BY update_time ASC
 */
router.get('/isp', (req, res) => {

  let start = req.query.start;
  let end  = req.query.end;
  let content_id = req.query.content_id;

  const query = 'SELECT update_time, kt, sk, lg, etc  FROM web.isp_day\n' +
      'WHERE update_time > $1 \n' +
      'AND update_time < $2 \n' +
      'AND owner_isp = \'0\' \n' +
      'AND content_id = $3 \n' +
      'ORDER BY update_time ASC';

  pool.query(query,  [`${start}  00:00`, `${end} 00:05`, content_id]).then( results => {
    res.status(200).json(results.rows);
  }).catch(error => new Error())
})


module.exports = router;
