const { Pool, Client } = require('pg');
const pool = new Pool({
    user: 'postgres',
    password: 'gkgkgk12#',
    host: 'localhost',
    port: '5432',
    database: 'ngrid'
});

function getClient() {
    return pool;
}


module.exports = {
    getClient: getClient
}
