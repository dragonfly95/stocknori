// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable').DataTable({
    "scrollY": "400px",
    "scrollX": true,
    "paging": false,
    "searching": false
  });
});

// https://codepen.io/RedJokingInn/pen/mRQqda