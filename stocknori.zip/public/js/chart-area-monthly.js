$(document).ready(function () {
// Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#292b2c';

    $('[name="btnSearch"]').on('click', function (){
        loadData();
    });

        var obj = [{"update_date":"2021-03-31T15:00:00.000Z","cdn":"330","p2p":"538"},{"update_date":"2021-04-01T15:00:00.000Z","cdn":"540","p2p":"535"},{"update_date":"2021-04-02T15:00:00.000Z","cdn":"575","p2p":"535"},{"update_date":"2021-04-03T15:00:00.000Z","cdn":"566","p2p":"550"},{"update_date":"2021-04-04T15:00:00.000Z","cdn":"654","p2p":"610"},{"update_date":"2021-04-05T15:00:00.000Z","cdn":"589","p2p":"498"},{"update_date":"2021-04-06T15:00:00.000Z","cdn":"470","p2p":"557"},{"update_date":"2021-04-07T15:00:00.000Z","cdn":"404","p2p":"417"},{"update_date":"2021-04-08T15:00:00.000Z","cdn":"505","p2p":"436"},{"update_date":"2021-04-09T15:00:00.000Z","cdn":"383","p2p":"410"},{"update_date":"2021-04-10T15:00:00.000Z","cdn":"255","p2p":"322"},{"update_date":"2021-04-11T15:00:00.000Z","cdn":"238","p2p":"288"},{"update_date":"2021-04-12T15:00:00.000Z","cdn":"277","p2p":"373"},{"update_date":"2021-04-13T15:00:00.000Z","cdn":"201","p2p":"357"},{"update_date":"2021-04-14T15:00:00.000Z","cdn":"268","p2p":"523"},{"update_date":"2021-04-15T15:00:00.000Z","cdn":"207","p2p":"308"},{"update_date":"2021-04-16T15:00:00.000Z","cdn":"209","p2p":"360"},{"update_date":"2021-04-17T15:00:00.000Z","cdn":"223","p2p":"264"},{"update_date":"2021-04-18T15:00:00.000Z","cdn":"182","p2p":"271"},{"update_date":"2021-04-19T15:00:00.000Z","cdn":"182","p2p":"340"},{"update_date":"2021-04-20T15:00:00.000Z","cdn":"292","p2p":"471"},{"update_date":"2021-04-21T15:00:00.000Z","cdn":"228","p2p":"398"},{"update_date":"2021-04-22T15:00:00.000Z","cdn":"231","p2p":"385"},{"update_date":"2021-04-23T15:00:00.000Z","cdn":"293","p2p":"357"},{"update_date":"2021-04-24T15:00:00.000Z","cdn":"226","p2p":"232"},{"update_date":"2021-04-25T15:00:00.000Z","cdn":"134","p2p":"135"},{"update_date":"2021-04-26T15:00:00.000Z","cdn":"126","p2p":"141"},{"update_date":"2021-04-27T15:00:00.000Z","cdn":"119","p2p":"205"},{"update_date":"2021-04-28T15:00:00.000Z","cdn":"205","p2p":"393"},{"update_date":"2021-04-29T15:00:00.000Z","cdn":"164","p2p":"224"}]

        // var obj = [];
        var p2p = [];
        var cdn = [];
        var update_time = [];
        var yAxes_max = 500;

        var ctx = document.getElementById("myAreaChart");
        new Chart(ctx, {});

        $('#dataTable').DataTable({
            "scrollY": "400px",
            "scrollX": true,
            "paging": false,
            "searching": false,
            "aaData": obj,
            "aoColumns": [
                {"mDataProp": "p2p"},
                {"mDataProp": "cdn"},
                {"mDataProp": "update_date"}
            ]
        });

    function loadData() {
        var start = $('[name="start"]').val();
        var end = $('[name="end"]').val();
        var content_id = $("input[name='content_id']:checked").val();
        if (start == '') {
            alert('시작일을 입력해주세요.');
            return;
        }
        if (end == '') {
            alert('마침일을 입력해주세요.');
            return;
        }
        $.ajax({
            url: "/repository/monthly",
            data: {"start": start, "end": end, "content_id": content_id},
            success: function (response) {

                obj = response;
                $.each(obj, function (indexInArray, valueOfElement) {
                    p2p.push(valueOfElement.p2p);
                    cdn.push(valueOfElement.cdn);
                    update_time.push(valueOfElement.update_date);
                });

                var max = p2p.concat(cdn);
                if (max.length != 0) {
                    yAxes_max = max.reduce(function (previous, current) {
                        return parseInt(previous) > parseInt(current) ? parseInt(previous) : parseInt(current);
                    });
                } else {
                    alert('No Data');
                }

                // chart start to render

                // Area Chart Example
                var myLineChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: update_time,
                        datasets: [{
                            label: "P2P",
                            lineTension: 0.3,
                            backgroundColor: "rgba(2,117,216,0.2)",
                            borderColor: "rgba(2,117,216,1)",
                            pointRadius: 0,
                            pointBackgroundColor: "rgba(2,117,216,1)",
                            pointBorderColor: "rgba(255,255,255,0.8)",
                            pointHoverRadius: 5,
                            pointHoverBackgroundColor: "rgba(2,117,216,1)",
                            pointHitRadius: 50,
                            pointBorderWidth: 2,
                            data: p2p,
                        },
                            {
                                label: "CDN",
                                lineTension: 0.3,
                                backgroundColor: "rgba(220,0,0,0.2)",
                                borderColor: "rgba(220,0,0,1)",
                                pointRadius: 0,
                                pointBackgroundColor: "rgba(220,0,0,1)",
                                pointBorderColor: "rgba(255,255,255,0.8)",
                                pointHoverRadius: 5,
                                pointHoverBackgroundColor: "rgba(220,0,0,1)",
                                pointHitRadius: 50,
                                pointBorderWidth: 2,
                                data: cdn,
                            }],
                    },
                    options: {
                        scales: {
                            xAxes: [{
                                time: {
                                    unit: 'date'
                                },
                                gridLines: {
                                    display: true
                                },
                                ticks: {
                                    maxTicksLimit: 7
                                }
                            }],
                            yAxes: [{
                                ticks: {
                                    min: 0,
                                    max: yAxes_max,
                                    maxTicksLimit: 5
                                },
                                gridLines: {
                                    color: "rgba(0, 0, 0, .125)",
                                }
                            }],
                        },
                        legend: {
                            display: true
                        }
                    }
                });

                //-- chart rendered
                $('#dataTable').dataTable().fnClearTable();
                if( obj.length != 0 ) {
                    $('#dataTable').dataTable().fnAddData(obj);
                }
            },
            error: function (error) {
                console.log(error);
                alert('데이터 조회에 문제가 있습니다');
            }
        });

    }  // function loadData

    $('input:radio[name="content_id"]').eq(0).attr("checked", true);
    loadData();

});
