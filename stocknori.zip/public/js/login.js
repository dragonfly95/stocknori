
$(document).ready(function() {

    $('#btnLogin').on('click', function() {

        var userId = $('[name="userId"]').val();
        var userPass = $('[name="userPass"]').val();

        if (userId == '' || userPass == '') {
            alert('아이디 패스워드를 입력해주세요');
            return;
        }

        var _form = document.querySelector('form');
        _form.method = 'post';
        _form.action = '/login';
        _form.submit();
    })
});