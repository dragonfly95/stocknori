$(document).ready(function () {
// Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#292b2c';


    $('[name="btnSearch"]').on('click', function (){
        loadData();
    });

        var obj = [{"update_time":"2021-04-21T15:05:00.000Z","int4":88},{"update_time":"2021-04-21T15:10:00.000Z","int4":90},{"update_time":"2021-04-21T15:15:00.000Z","int4":90},{"update_time":"2021-04-21T15:20:00.000Z","int4":92},{"update_time":"2021-04-21T15:25:00.000Z","int4":90},{"update_time":"2021-04-21T15:30:00.000Z","int4":89},{"update_time":"2021-04-21T15:35:00.000Z","int4":86},{"update_time":"2021-04-21T15:40:00.000Z","int4":87},{"update_time":"2021-04-21T15:45:00.000Z","int4":90},{"update_time":"2021-04-21T15:50:00.000Z","int4":89},{"update_time":"2021-04-21T15:55:00.000Z","int4":89},{"update_time":"2021-04-21T16:00:00.000Z","int4":60},{"update_time":"2021-04-21T16:00:00.000Z","int4":88},{"update_time":"2021-04-21T16:05:00.000Z","int4":92},{"update_time":"2021-04-21T16:10:00.000Z","int4":83},{"update_time":"2021-04-21T16:15:00.000Z","int4":87},{"update_time":"2021-04-21T16:20:00.000Z","int4":86},{"update_time":"2021-04-21T16:25:00.000Z","int4":88},{"update_time":"2021-04-21T16:30:00.000Z","int4":91},{"update_time":"2021-04-21T16:35:00.000Z","int4":90},{"update_time":"2021-04-21T16:40:00.000Z","int4":89},{"update_time":"2021-04-21T16:45:00.000Z","int4":90},{"update_time":"2021-04-21T16:50:00.000Z","int4":87},{"update_time":"2021-04-21T16:55:00.000Z","int4":86},{"update_time":"2021-04-21T17:00:00.000Z","int4":90},{"update_time":"2021-04-21T17:05:00.000Z","int4":93},{"update_time":"2021-04-21T17:10:00.000Z","int4":92},{"update_time":"2021-04-21T17:15:00.000Z","int4":92},{"update_time":"2021-04-21T17:20:00.000Z","int4":89},{"update_time":"2021-04-21T17:25:00.000Z","int4":93},{"update_time":"2021-04-21T17:30:00.000Z","int4":94},{"update_time":"2021-04-21T17:35:00.000Z","int4":91},{"update_time":"2021-04-21T17:40:00.000Z","int4":92},{"update_time":"2021-04-21T17:45:00.000Z","int4":93},{"update_time":"2021-04-21T17:50:00.000Z","int4":92},{"update_time":"2021-04-21T17:55:00.000Z","int4":95},{"update_time":"2021-04-21T18:00:00.000Z","int4":88},{"update_time":"2021-04-21T18:05:00.000Z","int4":92},{"update_time":"2021-04-21T18:10:00.000Z","int4":91},{"update_time":"2021-04-21T18:15:00.000Z","int4":90},{"update_time":"2021-04-21T18:20:00.000Z","int4":88},{"update_time":"2021-04-21T18:25:00.000Z","int4":87},{"update_time":"2021-04-21T18:30:00.000Z","int4":90},{"update_time":"2021-04-21T18:35:00.000Z","int4":87},{"update_time":"2021-04-21T18:40:00.000Z","int4":80},{"update_time":"2021-04-21T18:45:00.000Z","int4":77},{"update_time":"2021-04-21T18:50:00.000Z","int4":86},{"update_time":"2021-04-21T18:55:00.000Z","int4":84},{"update_time":"2021-04-21T19:00:00.000Z","int4":86},{"update_time":"2021-04-21T19:05:00.000Z","int4":84},{"update_time":"2021-04-21T19:10:00.000Z","int4":82},{"update_time":"2021-04-21T19:15:00.000Z","int4":82},{"update_time":"2021-04-21T19:20:00.000Z","int4":93},{"update_time":"2021-04-21T19:25:00.000Z","int4":85},{"update_time":"2021-04-21T19:30:00.000Z","int4":76},{"update_time":"2021-04-21T19:35:00.000Z","int4":67},{"update_time":"2021-04-21T19:40:00.000Z","int4":38},{"update_time":"2021-04-21T19:45:00.000Z","int4":41},{"update_time":"2021-04-21T19:50:00.000Z","int4":37},{"update_time":"2021-04-21T19:55:00.000Z","int4":52},{"update_time":"2021-04-21T20:00:00.000Z","int4":70},{"update_time":"2021-04-21T20:05:00.000Z","int4":75},{"update_time":"2021-04-21T20:10:00.000Z","int4":74},{"update_time":"2021-04-21T20:15:00.000Z","int4":77},{"update_time":"2021-04-21T20:20:00.000Z","int4":81},{"update_time":"2021-04-21T20:25:00.000Z","int4":78},{"update_time":"2021-04-21T20:30:00.000Z","int4":72},{"update_time":"2021-04-21T20:35:00.000Z","int4":66},{"update_time":"2021-04-21T20:40:00.000Z","int4":66},{"update_time":"2021-04-21T20:45:00.000Z","int4":75},{"update_time":"2021-04-21T20:50:00.000Z","int4":64},{"update_time":"2021-04-21T20:55:00.000Z","int4":68},{"update_time":"2021-04-21T21:00:00.000Z","int4":62},{"update_time":"2021-04-21T21:05:00.000Z","int4":34},{"update_time":"2021-04-21T21:10:00.000Z","int4":15},{"update_time":"2021-04-21T21:15:00.000Z","int4":12},{"update_time":"2021-04-21T21:20:00.000Z","int4":27},{"update_time":"2021-04-21T21:25:00.000Z","int4":32},{"update_time":"2021-04-21T21:30:00.000Z","int4":24},{"update_time":"2021-04-21T21:35:00.000Z","int4":23},{"update_time":"2021-04-21T21:40:00.000Z","int4":16},{"update_time":"2021-04-21T21:45:00.000Z","int4":35},{"update_time":"2021-04-21T21:50:00.000Z","int4":29},{"update_time":"2021-04-21T21:55:00.000Z","int4":28},{"update_time":"2021-04-21T22:00:00.000Z","int4":26},{"update_time":"2021-04-21T22:05:00.000Z","int4":31},{"update_time":"2021-04-21T22:10:00.000Z","int4":31},{"update_time":"2021-04-21T22:15:00.000Z","int4":30},{"update_time":"2021-04-21T22:20:00.000Z","int4":66},{"update_time":"2021-04-21T22:25:00.000Z","int4":69},{"update_time":"2021-04-21T22:30:00.000Z","int4":78},{"update_time":"2021-04-21T22:35:00.000Z","int4":89},{"update_time":"2021-04-21T22:40:00.000Z","int4":88},{"update_time":"2021-04-21T22:45:00.000Z","int4":82},{"update_time":"2021-04-21T22:50:00.000Z","int4":86},{"update_time":"2021-04-21T22:55:00.000Z","int4":93},{"update_time":"2021-04-21T23:00:00.000Z","int4":79},{"update_time":"2021-04-21T23:05:00.000Z","int4":75},{"update_time":"2021-04-21T23:10:00.000Z","int4":69},{"update_time":"2021-04-21T23:15:00.000Z","int4":76},{"update_time":"2021-04-21T23:20:00.000Z","int4":72},{"update_time":"2021-04-21T23:25:00.000Z","int4":73},{"update_time":"2021-04-21T23:30:00.000Z","int4":81},{"update_time":"2021-04-21T23:35:00.000Z","int4":76},{"update_time":"2021-04-21T23:40:00.000Z","int4":84},{"update_time":"2021-04-21T23:45:00.000Z","int4":84},{"update_time":"2021-04-21T23:50:00.000Z","int4":81},{"update_time":"2021-04-21T23:55:00.000Z","int4":82},{"update_time":"2021-04-22T00:00:00.000Z","int4":74},{"update_time":"2021-04-22T00:05:00.000Z","int4":64},{"update_time":"2021-04-22T00:10:00.000Z","int4":78},{"update_time":"2021-04-22T00:15:00.000Z","int4":90},{"update_time":"2021-04-22T00:20:00.000Z","int4":72},{"update_time":"2021-04-22T00:25:00.000Z","int4":76},{"update_time":"2021-04-22T00:30:00.000Z","int4":82},{"update_time":"2021-04-22T00:35:00.000Z","int4":81},{"update_time":"2021-04-22T00:40:00.000Z","int4":70},{"update_time":"2021-04-22T00:45:00.000Z","int4":79},{"update_time":"2021-04-22T00:50:00.000Z","int4":91},{"update_time":"2021-04-22T00:55:00.000Z","int4":84},{"update_time":"2021-04-22T01:00:00.000Z","int4":78},{"update_time":"2021-04-22T01:05:00.000Z","int4":78},{"update_time":"2021-04-22T01:10:00.000Z","int4":74},{"update_time":"2021-04-22T01:15:00.000Z","int4":72},{"update_time":"2021-04-22T01:20:00.000Z","int4":71},{"update_time":"2021-04-22T01:25:00.000Z","int4":79},{"update_time":"2021-04-22T01:30:00.000Z","int4":81},{"update_time":"2021-04-22T01:35:00.000Z","int4":80},{"update_time":"2021-04-22T01:40:00.000Z","int4":84},{"update_time":"2021-04-22T01:45:00.000Z","int4":80},{"update_time":"2021-04-22T01:50:00.000Z","int4":82},{"update_time":"2021-04-22T01:55:00.000Z","int4":79},{"update_time":"2021-04-22T02:00:00.000Z","int4":85},{"update_time":"2021-04-22T02:05:00.000Z","int4":84},{"update_time":"2021-04-22T02:10:00.000Z","int4":81},{"update_time":"2021-04-22T02:15:00.000Z","int4":82},{"update_time":"2021-04-22T02:20:00.000Z","int4":84},{"update_time":"2021-04-22T02:25:00.000Z","int4":84},{"update_time":"2021-04-22T02:30:00.000Z","int4":87},{"update_time":"2021-04-22T02:35:00.000Z","int4":87},{"update_time":"2021-04-22T02:40:00.000Z","int4":85},{"update_time":"2021-04-22T02:45:00.000Z","int4":89},{"update_time":"2021-04-22T02:50:00.000Z","int4":86},{"update_time":"2021-04-22T02:55:00.000Z","int4":84},{"update_time":"2021-04-22T03:00:00.000Z","int4":89},{"update_time":"2021-04-22T03:05:00.000Z","int4":91},{"update_time":"2021-04-22T03:10:00.000Z","int4":89},{"update_time":"2021-04-22T03:15:00.000Z","int4":91},{"update_time":"2021-04-22T03:20:00.000Z","int4":88},{"update_time":"2021-04-22T03:25:00.000Z","int4":90},{"update_time":"2021-04-22T03:30:00.000Z","int4":90},{"update_time":"2021-04-22T03:35:00.000Z","int4":88},{"update_time":"2021-04-22T03:40:00.000Z","int4":89},{"update_time":"2021-04-22T03:45:00.000Z","int4":90},{"update_time":"2021-04-22T03:50:00.000Z","int4":89},{"update_time":"2021-04-22T03:55:00.000Z","int4":90},{"update_time":"2021-04-22T04:00:00.000Z","int4":88},{"update_time":"2021-04-22T04:05:00.000Z","int4":86},{"update_time":"2021-04-22T04:10:00.000Z","int4":84},{"update_time":"2021-04-22T04:15:00.000Z","int4":85},{"update_time":"2021-04-22T04:20:00.000Z","int4":89},{"update_time":"2021-04-22T04:25:00.000Z","int4":86},{"update_time":"2021-04-22T04:30:00.000Z","int4":85},{"update_time":"2021-04-22T04:35:00.000Z","int4":88},{"update_time":"2021-04-22T04:40:00.000Z","int4":86},{"update_time":"2021-04-22T04:45:00.000Z","int4":86},{"update_time":"2021-04-22T04:50:00.000Z","int4":86},{"update_time":"2021-04-22T04:55:00.000Z","int4":88},{"update_time":"2021-04-22T05:00:00.000Z","int4":89},{"update_time":"2021-04-22T05:05:00.000Z","int4":92},{"update_time":"2021-04-22T05:10:00.000Z","int4":88},{"update_time":"2021-04-22T05:15:00.000Z","int4":90},{"update_time":"2021-04-22T05:20:00.000Z","int4":90},{"update_time":"2021-04-22T05:25:00.000Z","int4":90},{"update_time":"2021-04-22T05:30:00.000Z","int4":91},{"update_time":"2021-04-22T05:35:00.000Z","int4":94},{"update_time":"2021-04-22T05:40:00.000Z","int4":91},{"update_time":"2021-04-22T05:45:00.000Z","int4":87},{"update_time":"2021-04-22T05:50:00.000Z","int4":88},{"update_time":"2021-04-22T05:55:00.000Z","int4":91},{"update_time":"2021-04-22T06:00:00.000Z","int4":89},{"update_time":"2021-04-22T06:05:00.000Z","int4":92},{"update_time":"2021-04-22T06:10:00.000Z","int4":92},{"update_time":"2021-04-22T06:15:00.000Z","int4":90},{"update_time":"2021-04-22T06:20:00.000Z","int4":91},{"update_time":"2021-04-22T06:25:00.000Z","int4":92},{"update_time":"2021-04-22T06:30:00.000Z","int4":89},{"update_time":"2021-04-22T06:35:00.000Z","int4":91},{"update_time":"2021-04-22T06:40:00.000Z","int4":88},{"update_time":"2021-04-22T06:45:00.000Z","int4":88},{"update_time":"2021-04-22T06:50:00.000Z","int4":84},{"update_time":"2021-04-22T06:55:00.000Z","int4":89},{"update_time":"2021-04-22T07:00:00.000Z","int4":89},{"update_time":"2021-04-22T07:05:00.000Z","int4":87},{"update_time":"2021-04-22T07:10:00.000Z","int4":87},{"update_time":"2021-04-22T07:15:00.000Z","int4":87},{"update_time":"2021-04-22T07:20:00.000Z","int4":92},{"update_time":"2021-04-22T07:25:00.000Z","int4":90},{"update_time":"2021-04-22T07:30:00.000Z","int4":87},{"update_time":"2021-04-22T07:35:00.000Z","int4":90},{"update_time":"2021-04-22T07:40:00.000Z","int4":88},{"update_time":"2021-04-22T07:45:00.000Z","int4":90},{"update_time":"2021-04-22T07:50:00.000Z","int4":91},{"update_time":"2021-04-22T07:55:00.000Z","int4":90},{"update_time":"2021-04-22T08:00:00.000Z","int4":89},{"update_time":"2021-04-22T08:05:00.000Z","int4":89},{"update_time":"2021-04-22T08:10:00.000Z","int4":85},{"update_time":"2021-04-22T08:15:00.000Z","int4":88},{"update_time":"2021-04-22T08:20:00.000Z","int4":90},{"update_time":"2021-04-22T08:25:00.000Z","int4":88},{"update_time":"2021-04-22T08:30:00.000Z","int4":92},{"update_time":"2021-04-22T08:35:00.000Z","int4":93},{"update_time":"2021-04-22T08:40:00.000Z","int4":90},{"update_time":"2021-04-22T08:45:00.000Z","int4":91},{"update_time":"2021-04-22T08:50:00.000Z","int4":92},{"update_time":"2021-04-22T08:55:00.000Z","int4":89},{"update_time":"2021-04-22T09:00:00.000Z","int4":87},{"update_time":"2021-04-22T09:05:00.000Z","int4":92},{"update_time":"2021-04-22T09:10:00.000Z","int4":93},{"update_time":"2021-04-22T09:15:00.000Z","int4":89},{"update_time":"2021-04-22T09:20:00.000Z","int4":92},{"update_time":"2021-04-22T09:25:00.000Z","int4":93},{"update_time":"2021-04-22T09:30:00.000Z","int4":91},{"update_time":"2021-04-22T09:35:00.000Z","int4":90},{"update_time":"2021-04-22T09:40:00.000Z","int4":91},{"update_time":"2021-04-22T09:45:00.000Z","int4":91},{"update_time":"2021-04-22T09:50:00.000Z","int4":87},{"update_time":"2021-04-22T09:55:00.000Z","int4":88},{"update_time":"2021-04-22T10:00:00.000Z","int4":90},{"update_time":"2021-04-22T10:05:00.000Z","int4":89},{"update_time":"2021-04-22T10:10:00.000Z","int4":91},{"update_time":"2021-04-22T10:15:00.000Z","int4":92},{"update_time":"2021-04-22T10:20:00.000Z","int4":91},{"update_time":"2021-04-22T10:25:00.000Z","int4":91},{"update_time":"2021-04-22T10:30:00.000Z","int4":93},{"update_time":"2021-04-22T10:35:00.000Z","int4":89},{"update_time":"2021-04-22T10:40:00.000Z","int4":88},{"update_time":"2021-04-22T10:45:00.000Z","int4":89},{"update_time":"2021-04-22T10:50:00.000Z","int4":90},{"update_time":"2021-04-22T10:55:00.000Z","int4":92},{"update_time":"2021-04-22T11:00:00.000Z","int4":92},{"update_time":"2021-04-22T11:05:00.000Z","int4":92},{"update_time":"2021-04-22T11:10:00.000Z","int4":91},{"update_time":"2021-04-22T11:15:00.000Z","int4":90},{"update_time":"2021-04-22T11:20:00.000Z","int4":89},{"update_time":"2021-04-22T11:25:00.000Z","int4":90},{"update_time":"2021-04-22T11:30:00.000Z","int4":90},{"update_time":"2021-04-22T11:35:00.000Z","int4":91},{"update_time":"2021-04-22T11:40:00.000Z","int4":91},{"update_time":"2021-04-22T11:45:00.000Z","int4":90},{"update_time":"2021-04-22T11:50:00.000Z","int4":90},{"update_time":"2021-04-22T11:55:00.000Z","int4":90},{"update_time":"2021-04-22T12:00:00.000Z","int4":88},{"update_time":"2021-04-22T12:05:00.000Z","int4":90},{"update_time":"2021-04-22T12:10:00.000Z","int4":88},{"update_time":"2021-04-22T12:15:00.000Z","int4":90},{"update_time":"2021-04-22T12:20:00.000Z","int4":90},{"update_time":"2021-04-22T12:25:00.000Z","int4":90},{"update_time":"2021-04-22T12:30:00.000Z","int4":90},{"update_time":"2021-04-22T12:35:00.000Z","int4":90},{"update_time":"2021-04-22T12:40:00.000Z","int4":89},{"update_time":"2021-04-22T12:45:00.000Z","int4":86},{"update_time":"2021-04-22T12:50:00.000Z","int4":89},{"update_time":"2021-04-22T12:55:00.000Z","int4":89},{"update_time":"2021-04-22T13:00:00.000Z","int4":89},{"update_time":"2021-04-22T13:05:00.000Z","int4":88},{"update_time":"2021-04-22T13:10:00.000Z","int4":89},{"update_time":"2021-04-22T13:15:00.000Z","int4":87},{"update_time":"2021-04-22T13:20:00.000Z","int4":89},{"update_time":"2021-04-22T13:25:00.000Z","int4":85},{"update_time":"2021-04-22T13:30:00.000Z","int4":88},{"update_time":"2021-04-22T13:35:00.000Z","int4":87},{"update_time":"2021-04-22T13:40:00.000Z","int4":87},{"update_time":"2021-04-22T13:45:00.000Z","int4":86},{"update_time":"2021-04-22T13:50:00.000Z","int4":86},{"update_time":"2021-04-22T13:55:00.000Z","int4":84},{"update_time":"2021-04-22T14:00:00.000Z","int4":88},{"update_time":"2021-04-22T14:05:00.000Z","int4":89},{"update_time":"2021-04-22T14:10:00.000Z","int4":91},{"update_time":"2021-04-22T14:15:00.000Z","int4":90},{"update_time":"2021-04-22T14:20:00.000Z","int4":90},{"update_time":"2021-04-22T14:25:00.000Z","int4":88},{"update_time":"2021-04-22T14:30:00.000Z","int4":90},{"update_time":"2021-04-22T14:35:00.000Z","int4":90},{"update_time":"2021-04-22T14:40:00.000Z","int4":91},{"update_time":"2021-04-22T14:45:00.000Z","int4":92},{"update_time":"2021-04-22T14:50:00.000Z","int4":89},{"update_time":"2021-04-22T14:55:00.000Z","int4":89},{"update_time":"2021-04-22T15:00:00.000Z","int4":89}]

        var int4 = [];
        var update_time = [];
        var yAxes_max = 100;

        var ctx = document.getElementById("myAreaChart");
        new Chart(ctx, {});


    $('#dataTable').DataTable({
        "scrollY": "400px",
        "scrollX": true,
        "paging": false,
        "searching": false,
        "aaData": obj,
        "aoColumns": [
            {"mDataProp": "int4"},
            {"mDataProp": "update_time"}
        ]
    });

    function loadData() {
        var start = $('[name="start"]').val();
        var end = $('[name="end"]').val();
        var content_id = $("input[name='content_id']:checked").val();
        if (start == '') {
            alert('시작일을 입력해주세요.');
            return;
        }
        if (end == '') {
            alert('마침일을 입력해주세요.');
            return;
        }
        $.ajax({
            url: "/repository/effective",
            data: {"start": start, "end": end, "content_id": content_id},
            success: function (response) {

                obj = response;
                $.each(obj, function (indexInArray, valueOfElement) {
                    int4.push(valueOfElement.int4);
                    update_time.push(valueOfElement.update_time);
                });

                var max = int4;
                if (max.length != 0) {
                    yAxes_max = max.reduce(function (previous, current) {
                        return parseInt(previous) > parseInt(current) ? parseInt(previous) : parseInt(current);
                    });
                } else {
                    alert('No Data');
                }
                // chart start to render

                // Area Chart Example
                var myLineChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: update_time,
                        datasets: [{
                            label: "INT4",
                            lineTension: 0.3,
                            backgroundColor: "rgba(220,0,0,0.2)",
                            borderColor: "rgba(220,0,0,1)",
                            pointRadius: 0,
                            pointBackgroundColor: "rgba(220,0,0,1)",
                            pointBorderColor: "rgba(255,255,255,0.8)",
                            pointHoverRadius: 5,
                            pointHoverBackgroundColor: "rgba(220,0,0,1)",
                            pointHitRadius: 50,
                            pointBorderWidth: 2,
                            data: int4,
                        }],
                    },
                    options: {
                        scales: {
                            xAxes: [{
                                time: {
                                    unit: 'date'
                                },
                                gridLines: {
                                    display: true
                                },
                                ticks: {
                                    maxTicksLimit: 7
                                }
                            }],
                            yAxes: [{
                                ticks: {
                                    min: 0,
                                    max: yAxes_max,
                                    maxTicksLimit: 5
                                },
                                gridLines: {
                                    color: "rgba(0, 0, 0, .125)",
                                }
                            }],
                        },
                        legend: {
                            display: true
                        }
                    }
                });

                //-- chart rendered
                $('#dataTable').dataTable().fnClearTable();
                if(obj.length != 0) {
                    $('#dataTable').dataTable().fnAddData(obj);
                }

            },
            error: function (error) {
                console.log(error);
                alert('데이터 조회에 문제가 있습니다');
            }
        });

    } // function loadData

    $('input:radio[name="content_id"]').eq(0).attr("checked", true);
    loadData();

});
